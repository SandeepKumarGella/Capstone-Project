import { HashRouter } from 'react-router-dom';
import './App.scss';
import Footer from './components/Footer/Footer';
import Navbar from './components/Navbar/Navbar';
import appRoutes from './routes/appRoutes';

function App() {

  return (
    <HashRouter>
      <Navbar />
        {appRoutes}
      <Footer />
    </HashRouter>
  );
}

export default App;
