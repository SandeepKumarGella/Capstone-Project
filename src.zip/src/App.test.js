import { render, screen } from "@testing-library/react";
import App from "./App";

jest.mock("./routes/appRoutes", () => "appRoutes");

describe("App component", () => {
  it("renders without crashing", () => {
     render(
      // <MemoryRouter>
        <App />
      // </MemoryRouter>
    );
    expect(screen.getByText("appRoutes")).toBeInTheDocument();
  });
});

describe("App", () => {
  // test spec /test case begins
  // test('App comp has success! text', () => {
  //   // act
  //   // writing the logic to test whether the app comp has success text or not
  //   render(<App />); // Render into a container which is appended to document.body.
  //   // let's test whether the rendered comp has the success text or not
  //   const successTextEl = screen.getByText('success!'); // DOM Querying
  //   // Let's assert now
  //   expect(successTextEl).toBeInTheDocument();
  // });

  // 'it' is an alias of test
  it("has proper App Component", () => {
    // Act - Optional
    // Assert is mandatory for a test spec
    //  expect is from JEST
    // toBeTruthy is a matcher from '@testing-library/jest-dom';
    expect(App).toBeTruthy();
  });
});


