import React from 'react'; // Functional component with Arrow Function
import { NavLink } from 'react-router-dom';
// Navlink is used to link & navigate the pages in website. This Navlink is provide by react-router-dom library in react.
import PropTypes from 'prop-types';
// PropsType for also a library. It is used to check the receiving prop-values.

const List = [
  // List is array to store the group of objects data it contain: id, path & title.
  {
    id: 1,
    path: '/',
    title: 'Home'
  },
  {
    id: 2,
    path: '/products',
    title: 'Products'
  },
  {
    id: 3,
    path: '/about-us',
    title: 'About'
  },
  {
    id: 4,
    path: '/contact-us',
    title: 'Contact'
  }
];

const Footer = () => {
  // Footer component variable with arrow fn
  return (
    <div className="bg-dark" data-testid="footer-items">
       {/* bg-dark means background-color: black. this syntax is used in bootstrap */}
      <ul>
         {/* ul means unorder-list. which is used to group the list of elemnts */}
        {List.map(({ id, path, title }) => (
          // map fn is used to store list of elements in a single variable by looing process.This process avoid the code duplicate in our project.
          <li className="nav-item menu-icons mx-5 my-3 btn btn-outline-warning" key={id}>
            {/* li means list. It is used to arrange the data in series pattern */}
            <NavLink to={path} key={id} className="nav-link" aria-current="page">
              <b>{title}</b> {/* b-tag: Used to bold the title prop*/}
            </NavLink>
          </li>
        ))}
      </ul>
      <p className="text-light text-center my-1"> Copyright@ 2023 | Sandeep </p>
      {/* paragraph tag with bootstrap styling text-color: white,  align: center & margin-top: 1 (m = margin; y = vertical-axis)*/}
    </div>
  );
};

Footer.propTypes = {
  // props validation by using import the proptypes library.
  id: PropTypes.number,
  path: PropTypes.string,
  title: PropTypes.string
};

export default Footer; // export the footer component to use other components where-ever we want the footer data.
