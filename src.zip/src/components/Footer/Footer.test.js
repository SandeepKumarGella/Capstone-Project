import React from 'react';
import { render, screen } from '@testing-library/react';
import Footer from './Footer';
import { HashRouter } from 'react-router-dom';

test('Footer component should render', () => {
  render(
    <HashRouter>
      <Footer />
    </HashRouter>
  );
  const footer = screen.getByTestId('footer-items');
  expect(footer).toBeInTheDocument();
});

test('Footer component should render 4 NavLinks', () => {
  render(
    <HashRouter>
      <Footer />
    </HashRouter>
  );
  const footer = screen.getByTestId('footer-items');
  const links = footer.querySelectorAll('li');
  expect(links.length).toBe(4);
});

test('Footer component should render a copyright text', () => {
  render(
    <HashRouter>
      <Footer />
    </HashRouter>
  );
  const copyrightText = screen.getByText(/Copyright@ 2023 \| Sandeep/i);
  expect(copyrightText).toBeInTheDocument();
});
