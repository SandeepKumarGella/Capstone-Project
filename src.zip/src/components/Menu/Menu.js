// Functional component with Arrow Function
import React from 'react';
import MenuItem from './MenuItem'; // import MenuItem component to pass the Menu-props to Menuitem.

const Menu = () => {
  // Arrow fn
  const MenuList = [
    // Menulist is a variable which is used to store the array of objects.which consists id, title, path & address
    {
      id: 1,
      path: '/',
      address: '/assets/icons/Home.png',
      title: 'Home'
    },
    {
      id: 2,
      path: '/products',
      address: '/assets/icons/Product.png',
      title: 'Products'
    },
    {
      id: 3,
      path: '/about-us',
      address: '/assets/icons/AboutUs.png',
      title: 'About'
    },
    {
      id: 4,
      path: '/contact-us',
      address: '/assets/icons/ContactUs.png',
      title: 'Contact'
    }
  ];
  return (
    <div>
      <ul className="navbar-nav me-auto mb-2 mb-md-0">
        {/* ul means unorder-list. which is used to group the list of elemnts */}
        {MenuList.map(({ id, path, address, title }) => (
          // map fn is used to store list of elements in a single variable by looing process.This process avoid the code duplicate in our project.
          <MenuItem key={id} path={path} address={address} title={title} />
          // Tranfers the Menu props to MenuItem component.
        ))}
      </ul>
    </div>
  );
};

export default Menu;
// export the Menu component to use other components where-ever we want the Menu data.
