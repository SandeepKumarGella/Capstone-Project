import React from 'react';
import { render } from '@testing-library/react';
import Menu from './Menu';
import { HashRouter } from 'react-router-dom';

describe('<Menu />', () => {
  it('should render without crashing', () => {
    render(
      <HashRouter>
        <Menu />
      </HashRouter>
    );
  });

  it('should render 4 menu items', () => {
    const { getAllByRole } = render(
      <HashRouter>
        <Menu />
      </HashRouter>
    );
    const menuItems = getAllByRole('listitem');
    expect(menuItems).toHaveLength(4);
  });
});
