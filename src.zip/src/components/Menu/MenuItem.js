import React from 'react'; // Functional component with Arrow Function
import { NavLink } from 'react-router-dom';
// Navlink is used to link & navigate the pages in website. This Navlink is provide by react-router-dom library in react.
import PropTypes from 'prop-types';
// PropsType for also a library. It is used to check the receiving prop-values.

const MenuItem = ({ id, path, address, title }) => {
  // receiving props from parent Menu component. and the received props are in destructured format.
  return (
    <div>
      <li className="nav-item menu-icons">
        {/* li means list. It is used to arrange the data in series pattern */}
        <NavLink to={path} key={id} className="nav-link" aria-current="page">
          <img src={address} alt="title" width={20} height={30} />
          <b>{title}</b> {/* // b-tag is used to bold the tilte element */}
        </NavLink>
      </li>
    </div>
  );
};
MenuItem.propTypes = {
  // props validation by using import the proptypes library.
  id: PropTypes.number,
  path: PropTypes.string,
  address: PropTypes.string,
  title: PropTypes.string
};

export default MenuItem; // export the MenuItem component to use other components where-ever we want the MenuItem data.
