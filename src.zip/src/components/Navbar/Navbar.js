import React from 'react'; // default react library.
// Helmet is react-library. It is used to produce the title for pages in browser(output).
import { Helmet } from 'react-helmet';
// Navlink is a react-library. It is used to link the pages to provide path to link.
import { NavLink } from 'react-router-dom';
// Menu component is imported to pass the props to Nav section.
import Menu from '../Menu/Menu';

const Navbar = () => {
  // arrow function

  return (
    <div>
      {/* Helmet is used to set title name in render-side . cmd: npm i react-helmet  */}
      <Helmet>
        <title>Spark Clothing</title>
      </Helmet>

      {/* The below is from bootstrap-v 5.0(header-example).It is used to set our header perfect.
       Note: before using bootstrap snippets first link bootstrap with our project in index.js */}
      <nav className="navbar navbar-expand-lg navbar-light bg-white py-3 shadow-sm">
        <div className="container" data-testid="navbar-link">
          <NavLink className="navbar-brand" to="/">
            {/*  "/" means path to navigate to home page */}
            <div className="header-logo">
              <img src="/assets/images/LOGO.jpg" width={100} height={35} alt="Logo" />
              {/* The image logo is imported for public assets */}
              <span>
                {/* span tag is used to arrange the elements side by side */}
                <b>Spark Clothing</b>
                {/* The b-tag is used to bold the spark clothing title */}
              </span>
            </div>
          </NavLink>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarNavDropdown"
            aria-controls="navbarNavDropdown"
            aria-expanded="false"
            aria-label="Toggle navigation">
            <span className="navbar-toggler-icon" />
          </button>
          <div
            className="collapse navbar-collapse"
            id="navbarNavDropdown"
            data-testid="menuComponent">
            <Menu /> {/* import Menu component to provide all the data to Navbar */}
          </div>
        </div>
      </nav>
    </div>
  );
};

export default Navbar; // export is used to transfer the entire Navbar data to another component where-ever we want.
