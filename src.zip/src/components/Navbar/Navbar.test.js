import { render, screen } from '@testing-library/react';
import { HashRouter } from 'react-router-dom';
import Navbar from './Navbar';

describe('Navbar', () => {
  // test spec
  it('Navbar component renders correct title', () => {
    // Act
    render(
      <HashRouter>
        <Navbar />
      </HashRouter>
    );

    const title = screen.getByText('Spark Clothing');
    // Assert
    expect(title).toBeInTheDocument();
  });

  // Test that the component renders the correct logo image
  it('Navbar component renders correct logo image', () => {
    render(
      <HashRouter>
        <Navbar />
      </HashRouter>
    );
    const logo = screen.getByRole('img', { name: /logo/i });
    expect(logo).toBeInTheDocument();
  });

  it('should render the Menu component', () => {
    const { getByTestId } = render(
      <HashRouter>
        <Navbar />
      </HashRouter>
    );
    const menuComponent = getByTestId('menuComponent');
    expect(menuComponent).toBeInTheDocument();
  });
});
