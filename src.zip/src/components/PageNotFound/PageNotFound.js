import React from 'react'; // Functional component with Arrow Function
import { Helmet } from 'react-helmet';
// Helmet is react-library. It is used to produce the title for pages in browser(output).
import { NavLink } from 'react-router-dom';
import styled from 'styled-components';
// styled components is used to apply styling to the elemnts. This main provides we can write styling in js file.

const Button = styled.button`
  color: black;
  font-weight: bold;
  margin-left: 45%;
  margin-bottom: 10px;
  padding: 15px;
  border-radius: 15px;
  &:hover {
    background-color: black;
    color: white;
  }
`;

const PageNotFound = () => {
  // Arrow fn

  return (
    <div className="bg-warning">
      {' '}
      {/* bootstrap styling bg-warning = background-color: yellow;  */}
      <Helmet>
        {/* Helmet is used to set title name in render-side . cmd: npm i react-helmet  */}
        <title>PageNotFound</title>
      </Helmet>
      <div className="text-center">
        {' '}
        {/* styling for align the text to center of the page - syntax belongs to bootstrap */}
        <h1>404 Error</h1>
        <h3>Page Not Found</h3>
        <img src="./assets/gif/not-found-404error.gif" alt="pageNotFound" className="mb-3" />
      </div>
      {/* apply styling to button by styled component */}
      <NavLink to="/">
        <Button type="button" data-testid="goHomeLink" className="text-center">
          Go Home
        </Button>
      </NavLink>
    </div>
  );
};

export default PageNotFound; // export the PageNotFound component to use other components where-ever we want the PageNotFound data.
