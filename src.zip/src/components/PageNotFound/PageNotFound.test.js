import { render, screen } from '@testing-library/react';
import { MemoryRouter as Router } from 'react-router-dom';
import PageNotFound from './PageNotFound';

it('has go to home is working', () => {
  render(
    <Router>
      <PageNotFound />
    </Router>
  );

  const heading = screen.getByText('404 Error');
  expect(heading).toBeInTheDocument();

  const title = screen.getByText('Page Not Found');
  expect(title).toBeInTheDocument();

  const img = screen.getByRole('img', { name: /pageNotFound/i });
  expect(img).toBeInTheDocument('');

  const goHomelink = screen.getByTestId('goHomeLink');
  expect(goHomelink).toHaveTextContent('Go Home');
});

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),

  useNavigate: () => jest.fn()
}));
