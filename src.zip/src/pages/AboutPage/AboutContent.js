import React from 'react';// Functional component with Arrow Function
import { Helmet } from 'react-helmet';// Helmet is react-library. It is used to produce the title for pages in browser(output).
import styled from 'styled-components';// styled components is used to apply styling to the elemnts. This main provides we can write styling in js file.

{/* styling for MainContainer */}
const MainContainer = styled.div`
background-color: wheat;` 

const Para = styled.p`
padding: 10px;
margin: 10px;
font-size: 20px;
`

const AboutContent = () => {
  return (
    <> {/* <> tag: fragment-tag. It is used to wrap the elements as a single unit. */}
   <Helmet>{/* Helmet is used to set title name in render-side . cmd: npm i react-helmet  */}
    <title>AboutContent</title>
   </Helmet>
    <MainContainer>
      <h2 className='side-heading'>Details about Spark Cloth Shopping</h2>
      <h3 className='side-heading'>About Us Tagline:</h3>
      <Para>
        "We have the capabilities and experience to deliver the products you need to move forward.”
      </Para>
      <h2 className='side-heading'>The History:</h2>
      <Para>
        The story of Spark Clothings started in Bangalore in the year 2000 with wholesale of hosiery
        and woven garments, catering to the needs of various wholesalers and retailers across India.
        Bangalore textiles industry stands at USD 4.2 billion in 2012 and is globally famous for its
        hosiery products. The City has more than 5,000 garment manufacturing units and job work
        units, and is one of the most organised processing and finishing garment clusters in India.
        The firm came into existence in the year 2005 as a Sole Proprietorship concern in Bangalore,
        Tamil Nadu. In the year 2007 it started as family enterprise with a tiny shop selling Men’s
        apparel at much lesser price than market and expanded to full men’s wear during next six
        months. The journey continued and in 2011 launched its first exclusively brand store in
        Bangalore with bigger retailing space for Men’s wear, Women’s wear and Kids clothing.
      </Para>
      <Para>
        Spark Clothings is engaged into multiple business activities which include manufacturing,
        supplying and trading in a wide array of clothing products which include Women’s Wear, Polo
        T-Shirt, Girls T-Shirt and many more. The range offered is well acknowledged for their
        availability in stylish pattern, perfect finish and comfort in wearing. Products are
        developed after careful attention and hard work of Spark team. It aspires to render quality
        striven products which guarantee cheerfulness of end customer
      </Para>
    </MainContainer>
    </>
  );
};

export default AboutContent; // export the AboutContent component to use other components where-ever we want the AboutContent data.
