// unit Tests
// Arrange
import { render, screen } from '@testing-library/react';
import AboutContent from './AboutContent';

describe('AboutContent', () => {
  //test spec
  it("has 'About Us Tagline' as heading", () => {
    render(<AboutContent />);
    const heading = screen.getByText('About Us Tagline:');

    // Assert
    expect(heading).toBeInTheDocument();
  });

  it("has 'The History' as heading", () => {
    render(<AboutContent />);
    const heading = screen.getByText('The History:');

    // Assert
    expect(heading).toBeInTheDocument();
  });
});
