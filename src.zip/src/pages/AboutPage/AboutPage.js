import React from 'react'; // Functional component with Arrow Function
import styled from 'styled-components';
// styled components is used to apply styling to the elemnts. This main provides we can write styling in js file.
import { NavLink, Outlet } from 'react-router-dom';
// Navlink is used to link & navigate the pages in website.The Outlet is used to view the nested-routing content in our website. This Navlink & outlet is provide by react-router-dom library in react.
import { Helmet } from 'react-helmet';// Helmet is react-library. It is used to produce the title for pages in browser(output).

/* styling for button */
const Button = styled.button`
  color: black;
  font-weight: bold;
  margin: 10px;
  padding: 15px;
  border-radius: 15px;
 `;

const AboutPage = () => {
  return (
    <div>
      <Helmet> {/* Helmet is used to set title name in render-side . cmd: npm i react-helmet  */}
        <title>AboutPage</title>
      </Helmet>
      <img src='/assets/images/About Us.png' alt='...' width='100%' height='200px'/>
      <NavLink to='/about-us/content' className="nav-link" aria-current="page">
          <Button className='btn btn-outline-danger btn-lg' data-testid="Content">Content</Button>
      </NavLink>
        <Outlet/>{/* The Outlet is used to view the nested-routing content in our website. */}
    </div>
  );
};

export default AboutPage; // export the AboutPage component to use other components where-ever we want the AboutPage data.
