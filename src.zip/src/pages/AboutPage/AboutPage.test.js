import { render, screen } from '@testing-library/react';
import { MemoryRouter as Router } from 'react-router-dom';
import AboutPage from './AboutPage';

describe('AboutPage', () => {
  // test spec 
  // to check whether it is redirecting to the content page
  it('has to go to content page', () => {
    render(
      <Router>
        <AboutPage />
      </Router>
    );
     
    const openContent = screen.getByTestId('Content');
    expect(openContent).toHaveTextContent('Content');
  });
});

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: () => jest.fn()
}));
