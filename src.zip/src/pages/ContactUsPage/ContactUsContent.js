import React, { useState } from 'react'; // imported useState from react library
import { useFormik } from 'formik'; // imported useFormik from formik package for the form
import { Helmet } from 'react-helmet'; // Helmet is react-library. It is used to produce the title for pages in browser(output).

const ContactUsContent = () => {
  // const [contactUsDetail, setContactUsDetail] = useState([]); //useState for setting the contact us content
  const [isError, setIsError] = useState(false); //useState for setting error if error is caught
  const [isSaved, setIsSaved] = useState(false);

  //useFormik for submitting the form data to the local backend
  //And also validating the fields in the form
  const formik = useFormik({
    initialValues: {
      name: '',
      email: '',
      phone: '',
      message: ''
    },
    onSubmit: (values, { resetForm }) => {
      
      fetch('http://localhost:5000/getInTouchData', {
        method: 'POST',
        body: JSON.stringify(values),
        // headers: {
        //   'Content-type': 'application/json; charset=UTF-8'
        // }
      })
      .catch((err) => {
        //console.log(err);
        setIsError(true);
      });

      setIsSaved(true);
      resetForm({ values: '' });
    },
    validate:(values) => {
      let errors = {};
      if(!values.name){
        errors.name = "*Name Required"
      }
      if(!values.email){
        errors.email = "*Email Required"
      }
      if(!values.phone){
        errors.phone = "*Phone Required"
      }
      if(!values.message){
        errors.message = "*message Required"
      }
      return errors;
    }
  });

  //If error occur then we will display an alert with the below message
  if (isError) {
    return (
      <div className="alert alert-danger mt-5">Some Error Occured! Please Try again later.</div>
    );
  }

  //Get In Touch form takes the users name,e-mail,phone number and the message the user wants to convey
  //In the end the contact detail for Spark Clothing is displayed , by fetching the data from our local db (Address,Phone no. and E-mail)
  return (
    <> {/* <> tag: fragment-tag. It is used to wrap the elements as a single unit. */}
      <Helmet>  {/* Helmet is used to set title name in render-side . cmd: npm i react-helmet  */}
        <title>ContactUsContent</title>
      </Helmet>
      <div className="main-content">
        <div className="contact-wrapper" id="get-in-touch-form">
          <h1 className="text-center" data-testid="getInTouch" style={{color:'rgb(255, 0, 0)'}}>Get In Touch</h1>
          <div className="text-center">
              <img src="./assets/images/getintouch.png" alt="get-in-touch-logo"></img>
          </div>
          <form autoComplete="off" onSubmit={formik.handleSubmit} className="form-container">
            <label htmlFor="name">Name:</label>
            <input
              type="text"
              name="name"
              id="name"
              placeholder="Enter name"
              className="form-control"
              value={formik.values.name}
              onChange={formik.handleChange}
            />
             {formik.errors.name?<div className="errors text-danger fw-bold">{formik.errors.name}</div>:null}
            <br />{/* br-tag is used to break the line & the next statement is provided in a new line. */}
            <label htmlFor="email">E-mail:</label>
            <input
              type="email"
              name="email"
              id="email"
              placeholder="Enter mail"
              className="form-control"
              value={formik.values.email}
              onChange={formik.handleChange}
            />
             {formik.errors.email?<div className="errors text-danger fw-bold">{formik.errors.email}</div>:null}
            <br />{/* br-tag is used to break the line & the next statement is provided in a new line. */}
            <label htmlFor="phone">Phone:</label>
            <input
              type="number"
              name="phone"
              id="phone"
              placeholder="Enter phone number"
              className="form-control"
              value={formik.values.phone}
              onChange={formik.handleChange}
            />
             {formik.errors.phone?<div className="errors text-danger fw-bold">{formik.errors.phone}</div>:null}
            <br />{/* br-tag is used to break the line & the next statement is provided in a new line. */}
            <label htmlFor="message">Message:</label>
            <textarea
              type="text"
              name="message"
              id="message"
              placeholder="Enter message"
              className="form-control"
              value={formik.values.message}
              onChange={formik.handleChange}
            />
             {formik.errors.message?<div className="errors text-danger fw-bold">{formik.errors.message}</div>:null}
            <br />{/* br-tag is used to break the line & the next statement is provided in a new line. */}
            <button
              data-testid="submitBtn"
              className="btn btn-danger text-uppercase fs-5"
              type="submit">
              Submit
            </button>
          </form>
        </div>
        <div className="contact-images">
          <h2 className='text-center'>Waiting For Your Re-Visting</h2>
          <img src="https://images.myparkingsign.com/img/lg/K/thank-you-for-visiting-signature-sign-k2-0716.png" 
          alt="visit-again" width={500} />
          </div>
      </div>
      {isSaved ? 
      (<div data-testid="isSaved" className="alert alert-success">Form Submitted Successfully</div>) : ('')}
    </>
  );
};

export default ContactUsContent; // export the ContactUsContent component to use other components where-ever we want the ContactUsContent data.
