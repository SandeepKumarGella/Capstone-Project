import {  render, fireEvent } from '@testing-library/react'; 
import ContactUsContent from './ContactUsContent';

describe('ContactUsContent', () => {
  test('checking the labels and text in contactUs-form', () => {
    const { getByLabelText, getByTestId } = render(<ContactUsContent />);

    const nameInput = getByLabelText('Name:');
    const emailInput = getByLabelText('E-mail:');
    const phoneInput = getByLabelText('Phone:');
    const messageInput = getByLabelText('Message:');
    const submitButton = getByTestId('submitBtn');

    fireEvent.change(nameInput, { target: { value: 'sandeep' } });
    fireEvent.change(emailInput, { target: { value: 'sandeep@gmail.com' } });
    fireEvent.change(phoneInput, { target: { value: '1234321' } });
    fireEvent.change(messageInput, { target: { value: 'Hi, welcome to ContactUsContent' } });

    fireEvent.click(submitButton);
  });
});

 

