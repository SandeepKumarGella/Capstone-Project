import axios from 'axios'; // axios is a library that serves to create HTTP requests that are present externally.
import React, { Component } from 'react'; // React class component
import { Helmet } from 'react-helmet'; // Helmet is react-library. It is used to produce the title for pages in browser(output).
import { NavLink } from 'react-router-dom'; // Navlink is used to link & navigate the pages in website. This Navlink is provide by react-router-dom library in react

class ContactUsPage extends Component {
  state = {
    isLoading: true,
    isError: false,
    photos: []
  };

  componentDidMount() {
    //allow us to execute the React code.when the component is already placed in the DOM.
    axios //used to connect with backend .get is retrive the data from backend.
      .get('http://localhost:5000/contactData') // data is stored in db.json in contactUs array object.
      .then((response) => {
        this.setState({
          isLoading: false,
          isError: false,
          contactDetails: response.data // store the get data
        });
      })
      .catch((err) => {
        // catch is used to handle the errors.
        // console.log(err);
        this.setState({
          isLoading: false,
          isError: true
        });
      })
      .finally(() => {
        // finally is always executed at the end.
        //console.log(' It is Over!');
      });
  }
  render() {
    if (this.state.isLoading) {
      // if isLoading is true then this code snippet is  excuted.
      return (
        <div className="text-center">
          {/* spinner with center - bootstrap*/}
          <div className="spinner-border text-danger" role="status"></div>
        </div>
      );
    }
    if (this.state.isError) {
      // if any Error is Occur then this block is executed.
      return (
        <div className="alert alert-danger" role="alert">
          Sorry! Unable to fetch. Try again after some time
        </div>
      );
    }

    return (
      <div className="main-container">
        <Helmet>
          <title>ContactUsPage</title>
        </Helmet>
        <div className="contact-details" data-testid='contact'>
          {this.state.contactDetails.map((contact) => {
            return (
              <div key={contact.phone[0]}>
                <h2>Contact Us</h2>

                <img src="./assets/images/contact.png" width={300} alt="contactUs" />
                <div>
                  <div className="flex-container">
                    <div>
                      <h3>Address - {contact.address}</h3>
                    </div>
                    <div>
                      <h3 id="contact-details">
                        Phone - {contact.phone[0]},{contact.phone[1]}
                      </h3>
                    </div>
                    <div id="contact-details">
                      <h3>Email - {contact.email}</h3>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <div className="get-in-touch" data-testid='viewContact'>
          <div className="contact-wrapper mt-5">
            <NavLink to="/contact-us/content" className="nav-link" aria-current="page">
              <h1 className="text-center">Get In Touch</h1>
              <div className="text-center">
                <img src="./assets/images/getintouch.png" alt="get-in-touch-logo"></img>
              </div>
            </NavLink>
          </div>
        </div>
      </div>
    );
  }
}

export default ContactUsPage;



