import { HashRouter } from "react-router-dom";
import ContactUsPage from "./ContactUsPage";
import renderer from 'react-test-renderer';

describe("ContactUsPage", () => {
  // test spec
  describe('contactUsPage component', () => {
    it('has take snapshot in contactUsPage', () => {
      const snapshotInJson = renderer.create(
      <HashRouter>
        <ContactUsPage />
      </HashRouter>).toJSON();
      expect(snapshotInJson).toMatchSnapshot();
    });
  });
});








