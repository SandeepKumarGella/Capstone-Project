import React from 'react'; // Functional component with Arrow Function
import { Helmet } from 'react-helmet'; // Helmet is react-library. It is used to produce the title for pages in browser(output).
import { NavLink } from 'react-router-dom'; // Navlink is used to link & navigate the pages in website. This Navlink is provide by react-router-dom library in react.
import styled from 'styled-components'; // styled components is used to apply styling to the elemnts. This main provides we can write styling in js file.

const Button = styled.button`
  display: inline-block;
  color: black;
  font-weight: bold;
  margin: 10px;
  padding: 15px;
  border-radius: 15px;
`;

const H1 = styled.h1`
  display: block;
  color: white;
  font-size: 50px;
  margin: 10px;
  padding: 15px;
  border-radius: 15px;
`;

const HomePage = () => {
  return (
    <div>
      <Helmet>
        {' '}
        {/* Helmet is used to set title name in render-side . cmd: npm i react-helmet  */}
        <title>HomePage</title>
      </Helmet>
      <div>
        <div className="card bg-dark text-white border-0">
          {' '}
          {/* bootstrap Image and Over-layout text on that image card*/}
          <img src="/assets/images/Homebg.jpg" className="card-img" alt="main-img" />
          <div className="card-img-overlay d-flex justify-content-center flex-column">
            <div className="container">
              <h5 className="card-title display-3 fw-bolder mb-0">New Season Arrivals</h5>
              <p className="card-text lead fs-2">Check all trends</p>
            </div>
          </div>
        </div>

        {/* using carousel to display set of images in a flow. the code snippet is from bootstrap v-5.0 */}
        <div
          id="carouselExampleDark"
          className="carousel carousel-dark slide"
          data-bs-ride="carousel">
          <div className="carousel-indicators">
            <button
              type="button"
              data-bs-target="#carouselExampleDark"
              data-bs-slide-to={0}
              className="active"
              aria-current="true"
              aria-label="Slide 1"
            />
            <button
              type="button"
              data-bs-target="#carouselExampleDark"
              data-bs-slide-to={1}
              aria-label="Slide 2"
            />
            <button
              type="button"
              data-bs-target="#carouselExampleDark"
              data-bs-slide-to={2}
              aria-label="Slide 3"
            />
          </div>
          <div className="carousel-inner">
            <div className="carousel-item active" data-bs-interval={2000}>
              <img src="/assets/images/Carousel1.jpg" className="d-block w-100" alt="..." />
              <div className="carousel-caption d-none d-md-block">
                <H1>LIFE ISN'T PERFECT BUT YOUR OUTFIT CAN BE</H1>
                <NavLink to="/products">
                  <Button className="btn btn-outline-dark" data-testid="ShopNowBtn1">
                    Shop Now
                  </Button>
                </NavLink>
              </div>
            </div>
            <div className="carousel-item" data-bs-interval={2000}>
              <img src="/assets/images/Carousel2.jpg" className="d-block w-100" alt="..." />
              <div className="carousel-caption d-none d-md-block">
                <H1>If you are boring! Go Shopping.</H1>
                <NavLink to="/products">
                  <Button className="btn btn-outline-dark" data-testid="ShopNowBtn2">
                    Shop Now
                  </Button>
                </NavLink>
              </div>
            </div>
            <div className="carousel-item" data-bs-interval={2000}>
              <img src="/assets/images/Carousel3.jpg" className="d-block w-100" alt="..." />
              <div className="carousel-caption d-none d-md-block">
                <H1>Clothes are Just like friends you want quality, Not Quantity</H1>
                <NavLink to="/products">
                  <Button className="btn btn-outline-dark" data-testid="ShopNowBtn3">
                    Shop Now
                  </Button>
                </NavLink>
              </div>
            </div>
          </div>
          <button
            className="carousel-control-prev"
            type="button"
            data-bs-target="#carouselExampleDark"
            data-bs-slide="prev">
            <span className="carousel-control-prev-icon" aria-hidden="true" />
            <span className="visually-hidden">Previous</span>
          </button>
          <button
            className="carousel-control-next"
            type="button"
            data-bs-target="#carouselExampleDark"
            data-bs-slide="next">
            <span className="carousel-control-next-icon" aria-hidden="true" />
            <span className="visually-hidden">Next</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default HomePage; // export the HomePage component to use other components where-ever we want the HomePage data.
