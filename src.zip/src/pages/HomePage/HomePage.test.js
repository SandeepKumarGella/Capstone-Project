import { render, screen } from "@testing-library/react";
import { MemoryRouter as Router } from 'react-router-dom';
import HomePage from "./HomePage";

describe('HomePage', () => {
  // test spec
  it('has to go to Products page', () => {
    render(
      <Router>
        <HomePage />
      </Router>
    );
     
    const navigatetToProducts1 = screen.getByTestId('ShopNowBtn1');
    expect(navigatetToProducts1).toHaveTextContent('Shop Now');
    const navigatetToProducts2  = screen.getByTestId('ShopNowBtn2');
    expect(navigatetToProducts2 ).toHaveTextContent('Shop Now');
    const navigatetToProducts3  = screen.getByTestId('ShopNowBtn3');
    expect(navigatetToProducts3 ).toHaveTextContent('Shop Now');
  });

  it('has the main image with text', () => {
    render(
      <Router>
        <HomePage />
      </Router>
    );

    const img = screen.getByRole('img', {name: /main-img/i });
    expect(img).toBeInTheDocument('');
    const mainText = screen.getByText('New Season Arrivals');
    expect(mainText).toBeInTheDocument();
    const subText = screen.getByText('Check all trends');
    expect(subText).toBeInTheDocument();

  })
});

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: () => jest.fn()
}));


