import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styled from 'styled-components';
import { useFormik } from 'formik';
import { FaStar } from 'react-icons/fa';

const Form = styled.form`
  border: 1px solid grey;
  margin: 5px;
  padding: 20px;
  border-radius: 10px;
`;

const H2 = styled.h2`
  background-color: red;
  text-align: center;
  color: white;
  border-radius: 10px;
`;

const Feedback = () => {
  const [isError, setIsError] = useState(false);
  const [isSaved, setIsSaved] = useState(false);

  const [rating, setRating] = useState(null);
  const [hover, setHover] = useState(null);

  //useFormik for submitting the form data to the local backend
  //And also validating the fields in the form
  const formik = useFormik({
    initialValues: {
      name: '',
      email: '',
      phone: '',
      feedback: '',
      rating: ''
    },
    onSubmit: (values, { resetForm }) => {
      fetch('http://localhost:5000/Reviews', {
        method: 'POST',
        body: JSON.stringify(values),
        headers: {
          'Content-type': 'application/json; charset=UTF-8'
        }
      }).catch((err) => {
        //console.log(err);
        setIsError(true);
      });

      setIsSaved(true);
      resetForm({ values: '' });
    },
    validate: (values) => {
      let errors = {};
      if (!values.name) {
        errors.name = '*Name Required';
      }
      if (!values.email) {
        errors.email = '*Email Required';
      }
      if (!values.phone) {
        errors.phone = '*Phone Required';
      }
      if (!values.feedback) {
        errors.feedback = '*Feedback Required';
      } else if (values.feedback.trim().length < 50) {
        errors.feedback = 'Atleast 50 word required';
      }
      return errors;
    }
  });

  //If error occur then we will display an alert with the below message
  if (isError) {
    return (
      <div className="alert alert-danger mt-5">Some Error Occured! Please Try again later.</div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Products-FeedBack</title>
      </Helmet>
      {/* <div> */}
      <Form autoComplete="off" onSubmit={formik.handleSubmit} className="m-5 p-3">
        <H2>FeedBack</H2>
        <hr />
        <div className="row">
          <div className="col">
            <label htmlFor="name">Name</label>
            <input
              type="text"
              className="form-control"
              value={formik.values.name}
              onChange={formik.handleChange}
              id="name"
              aria-describedby="emailHelp"
              placeholder="Please Enter Your Name"
            />
            {formik.errors.name ? (
              <div className="errors text-danger fw-bold">{formik.errors.name}</div>
            ) : null}
          </div>
          <div className="col">
            <label htmlFor="email">Email</label>
            <input
              type="email"
              className="form-control"
              value={formik.values.email}
              onChange={formik.handleChange}
              id="email"
              aria-describedby="emailHelp"
              placeholder="Please Enter Your Email"
            />
            {formik.errors.email ? (
              <div className="errors text-danger fw-bold">{formik.errors.email}</div>
            ) : null}
          </div>
        </div>
        <div className="mt-3">
          <label htmlFor="phone" className="form-label">
            Phone
          </label>
          <input
            type="phone"
            className="form-control"
            value={formik.values.phone}
            onChange={formik.handleChange}
            id="phone"
            placeholder="Please Enter Your PhoneNumber"
          />
          {formik.errors.phone ? (
            <div className="errors text-danger fw-bold">{formik.errors.phone}</div>
          ) : null}
        </div>

        <div className="mt-3">
          <label htmlFor="feedback">FeedBack</label>
          <textarea
            type="text"
            className="form-control"
            value={formik.values.feedback}
            onChange={formik.handleChange}
            aria-describedby="phoneHelp"
            placeholder="Please Enter Your Feedback"
            id="feedback"
            minLength={150}
          />
          {formik.errors.feedback ? (
            <div className="errors text-danger fw-bold">{formik.errors.feedback}</div>
          ) : null}

          <div className="card text-center mx-5 my-3" style={{ width: '20rem' }}>
            <H2>Rating</H2>
            <div className="card-body">
              <div className="text-center">
                <h3>Rating:{rating}</h3>
                {[...Array(5)].map((star, i) => {
                  const ratingValue = i + 1;

                  return (
                    <label key={i}>
                      <input
                        type="radio"
                        name="rating"
                        onClick={() => setRating(ratingValue)}
                        id="rating"
                      />
                      <FaStar
                        className="star"
                        color={ratingValue <= (hover || rating) ? '#ffc107' : '#e4e5e9'}
                        size={20}
                        // onMouseEnter={() => setHover(ratingValue)}
                        // onMouseLeave={() => setHover(null)}
                      />
                    </label>
                  );
                })}
              </div>
              <div>
                <button
                  className="btn btn-outline-danger fw-bold my-3"
                  type="submit"
                  data-testid="submitBtn">
                  Submit
                </button>
              </div>
            </div>
          </div>
        </div>
      </Form>
      {isSaved ? (
        <div data-testid="isSaved" className="alert alert-success">
          FeedBack Submitted Successfully
        </div>
      ) : (
        ''
      )}
    </>
  );
};

export default Feedback;
