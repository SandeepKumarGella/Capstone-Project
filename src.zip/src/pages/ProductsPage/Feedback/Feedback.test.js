import {  render, fireEvent } from '@testing-library/react'; 
import Feedback from './Feedback'

describe('Feedback', () => { // checking feed-form  
  test('checking the labels and text in Feedback-form', () => {
    const { getByLabelText, getByTestId } = render(<Feedback/>);

    const nameInput = getByLabelText('Name');
    const emailInput = getByLabelText('Email');
    const phoneInput = getByLabelText('Phone');
    const feedbackInput = getByLabelText('FeedBack');
    const submitButton = getByTestId('submitBtn');

    fireEvent.change(nameInput, { target: { value: 'sandeep' } });
    fireEvent.change(emailInput, { target: { value: 'sandeep@gmail.com' } });
    fireEvent.change(phoneInput, { target: { value: '1234321' } });
    fireEvent.change(feedbackInput, { target: { value: 'Hi, welcome to Feedback' } });

    fireEvent.click(submitButton);
  });
});
















// import {  render, screen } from '@testing-library/react'; 
// import { HashRouter } from 'react-router-dom';
// import ContactUsContent from './ContactUsContent';

// describe('ContactUsContent', () => {
//   // To check the ContactUsContent
//   it('has proper contact form', () => {
//     render(<ContactUsContent />);

//     const name = screen.getByLabelText('Name:');
//     const phone = screen.getByLabelText('Phone:');
//     const email=screen.getByLabelText('E-mail:');
//     const message=screen.getByLabelText('Message:');
//     const submitBtn = screen.getByRole('button');

//     expect(name).toBeInTheDocument();
//     expect(phone).toBeInTheDocument();
//     expect(email).toBeInTheDocument();
//     expect(message).toBeInTheDocument();
//     expect(submitBtn).toBeInTheDocument();

//     expect(name).toHaveAttribute('type', 'text');
//     expect(phone).toHaveAttribute('type', 'number');
//     expect(email).toHaveAttribute('type', 'email');
//     expect(message).toHaveAttribute('type', 'text');
//   });

//   // // To check GetInTouch heading is in red color
//   // it('had GetInTouch with text color red', () => {
//   //   render(
//   //     <HashRouter>
//   //       <ContactUsContent/>
//   //     </HashRouter>
    
//   //   );
//   //   const getInTouch = screen.getByTestId('getInTouch');
//   //   // recommended to use color code in the hexa or rgb -- not the color names
//   //   expect(getInTouch).toHaveStyle('color: rgb(255, 0, 0)');

//   //   const logo = screen.getByRole('img', {name: 'get-in-touch-logo'});
//   //   expect(logo).toBeInTheDocument("");
//   // });

//   //   // has the image present In Get In Touch form
//   //   it('has the image present In Get In Touch form', () => {
//   //     render(
//   //       <HashRouter>
//   //         <ContactUsContent/>
//   //       </HashRouter>
      
//   //     );
//   //     const content = screen.getByText('Waiting For Your Re-Visting');
//   //     expect(content).toBeInTheDocument();
      
//   //     const img = screen.getByRole('img', {name: 'visit-again'});
//   //     expect(img).toBeInTheDocument("");
//   //   });
// });
