import React, { useEffect, useState} from 'react';
import { NavLink, Link, useLocation } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styled from 'styled-components'; // styled components is used to apply styling to the elemnts. This main provides we can write styling in js file.
import axios from 'axios';

const Button = styled.button`
  color: black;
  font-weight: bold;
  margin: 10px;
  padding: 15px;
  border-radius: 15px;
`;

const H1 = styled.h1`
  display: block;
  color: black;
  font-size: 50px;
  margin: 10px;
  padding: 15px;
  border-radius: 15px;
`;

const useQuery = () => new URLSearchParams(useLocation().search);

const ProductsPage = () => {
  
  const [isLoading, setIsLoading] = useState(false);
  const [isError, setIsError] = useState(false);
  const [products, setProducts] = useState([]);
  let api = null;
  let query = useQuery();
  let queryParam = query.get('category');
  
  if (queryParam === 'mens-wear') {
    api = 'http://localhost:5000/products?category=mens-wear';
  } else if (queryParam === 'womens-wear') {
    api = 'http://localhost:5000/products?category=womens-wear';
  } else if (queryParam === 'kids-wear') {
    api = 'http://localhost:5000/products?category=kids-wear';
  } else {
    api = 'http://localhost:5000/products';
  }

  useEffect(() => {
    axios //used to connect with backend .get is retrive the data from backend.
      .get(api) // data is stored in db.json in kids-clothing array object.
      .then((res) => {
        console.log(res.data);
        setIsLoading(false);
        setIsError(false);
        setProducts(res.data);
      })
      .catch((err) => {
        // catch is used to handle the errors.
        console.log(err);
        setIsLoading(false);
        setIsError(true);
        setProducts([]);
      })
      .finally(() => {
        // finally is always executed at the end.
        //console.log(' It is Over!');
      });
  }, [api]);

  if (isLoading) {
    // if isLoading is true then this code snippet is  excuted.
    return (
      <div className="text-center">
          {/* spinner with center - bootstrap*/}
        <div className="spinner-border text-danger" role="status"></div>
      </div>
    );
  }
  if (isError) {
    // if any Error is Occur then this block is executed.
    return (
      <div className="alert alert-danger" role="alert">
        Sorry! Unable to fetch. Try again after some time
      </div>
    );
  }

  return (
    <div>
      <Helmet>
        <title>ProductsPage</title>
      </Helmet>
      <div>
        <H1 className="text-center">Our Collections</H1>
        {/* <TabProducts/> */}
        <div className="d-flex flex-row justify-content-between" data-testid='mensCategory'>
          <NavLink to="/products?category=mens-wear" className="nav-link" aria-current="page">
            <Button className="btn btn-outline-danger btn-lg">MensClothing</Button>
          </NavLink>
          <NavLink to="/products?category=womens-wear" className="nav-link" aria-current="page" data-testid='womensCategory'>
            <Button className="btn btn-outline-danger btn-lg">WomensClothing</Button>
          </NavLink>
          <NavLink to="/products?category=kids-wear" className="nav-link" aria-current="page" data-testid='kidsCategory'>
            <Button className="btn btn-outline-danger btn-lg">KidsClothing</Button>
          </NavLink>
        </div>
        <hr />

        <div className="row mx-5 bg-warning">
          {products?.map(({ id, url, title, price, description }) => (
            // map fn is used to store list of elements in a single variable by looing process. This process avoid the code duplicate in our project.
            <div className="col-3 m-4" key={id}>
                {/* key: stable identification code */}
              <div className=" card product-card text-center">
                <img src={url} alt={title} height="250px" />
                <div className="card-body">
                  <Link to={`/products/${id}`} className="nav-link" aria-current="page">
                    <p className="card-text fw-bold text-info">{title}</p>
                  </Link>
                  <p>{description}</p>
                  <Button>Price Rs:{price}</Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ProductsPage;
