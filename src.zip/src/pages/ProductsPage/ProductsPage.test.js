import { render, screen } from '@testing-library/react';
import { MemoryRouter as Router } from 'react-router-dom';
import ProductsPage from './ProductsPage';

describe('ProductsPage', () => {
  // test spec 

  it('has to go to product page', () => {
    render(
      <Router>
        <ProductsPage/>
      </Router>
    );
     
    const openMensCategory = screen.getByTestId('mensCategory');
    expect(openMensCategory).toHaveTextContent('MensClothing');

    const openWomensCategory = screen.getByTestId('womensCategory');
    expect(openWomensCategory).toHaveTextContent('WomensClothing');

    const openKidsCategory = screen.getByTestId('kidsCategory');
    expect(openKidsCategory).toHaveTextContent('KidsClothing');
  });
});

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: () => jest.fn()
}));

describe('ProductsPage testing API Urls', () => {
  it('should return correct API URL when queryParam is mens-wear', () => {
    const queryParam = 'mens-wear';
    const ifElse = (queryParam) => {
      let api;
      if (queryParam === 'mens-wear') {
        api = 'http://localhost:5000/products?category=mens-wear';
      } else {
        api = 'http://localhost:5000/products';
      }
      return api;
    }

    const api = ifElse(queryParam);
    expect(api).toEqual('http://localhost:5000/products?category=mens-wear');
  });

  it('should return correct API URL when queryParam is womens-wear', () => {
    const queryParam = 'womens-wear';
    const ifElse = (queryParam) => {
      let api;
      if (queryParam === 'womens-wear') {
        api = 'http://localhost:5000/products?category=womens-wear';
      } else {
        api = 'http://localhost:5000/products';
      }
      return api;
    }

    const api = ifElse(queryParam);
    expect(api).toEqual('http://localhost:5000/products?category=womens-wear');
  });

  it('should return correct API URL when queryParam is kids-wear', () => {
    const queryParam = 'kids-wear';
    const ifElse = (queryParam) => {
      let api;
      if (queryParam === 'kids-wear') {
        api = 'http://localhost:5000/products?category=kids-wear';
      } else {
        api = 'http://localhost:5000/products';
      }
      return api;
    }

    const api = ifElse(queryParam);
    expect(api).toEqual('http://localhost:5000/products?category=kids-wear');
  });
});

describe('API call', () => {
  let mockSuccessResponse;
  let mockJsonPromise;
  let mockFetchPromise;

  beforeEach(() => {
    mockSuccessResponse = { data: [{ id: 1, name: 'product1' }, { id: 2, name: 'product2' }] };
    mockJsonPromise = Promise.resolve(mockSuccessResponse);
    mockFetchPromise = Promise.resolve({ json: () => mockJsonPromise });
    global.fetch = jest.fn().mockImplementation(() => mockFetchPromise);
  });

  afterEach(() => {
    global.fetch.mockClear();
  });

  it('calls fetch and returns data', async () => {
    const res = await global.fetch('/products');
    const data = await res.json();
    expect(global.fetch).toHaveBeenCalledTimes(1);
    expect(global.fetch).toHaveBeenCalledWith('/products');
    expect(data).toEqual(mockSuccessResponse);
  });
});






