import React, { useEffect, useState } from 'react';
import {NavLink, useParams } from 'react-router-dom';
import axios from 'axios';

const ProductDetails = () => {
  const [isLoading, setIsLoading] = useState(true);
  const [isError, setIsError] = useState(false);
  const [productDetails, setProductDetails] = useState([]);
  let param = useParams();
  let { id } = param;
  let url = `http://localhost:5000/products/${id}`;
  useEffect(() => {
    axios //used to connect with backend .get is retrive the data from backend.
      .get(url) // data is stored in db.json in kids-clothing array object.
      .then((res) => {
        console.log(res.data);
        setIsLoading(false);
        setIsError(false);
        setProductDetails(res.data);
      })
      .catch((err) => {
        // catch is used to handle the errors.
        console.log(err);
        setIsLoading(false);
        setIsError(true);
        setProductDetails([]);
      })
      .finally(() => {
        // finally is always executed at the end.
        console.log(' It is Over!');
      });
  }, [url]);

  console.log(url);
  console.log(productDetails);

  if (isLoading) {
    return <div className="text-center" data-testid="loader"></div>;
  }
  if (isError) {
    return (
      <div className="alert alert-danger" role="alert">
        Unable to fetch data. Try again after sometime!
      </div>
    );
  }
  return (
    <>
      <div className="container my-5 py-3">
        <div className='row'>
          <div className='col-md-6 d-flex justify-content-center mx-auto product'>
            <img src={productDetails.url} alt={productDetails.title} height="400px" />
          </div>
          <div className='col-md-6 d-flex flex-column justify-content-center'>
            <h1 className='display-5 fw-bold'>{productDetails.title}</h1>
            <hr/>
            <p className='lead'>{productDetails.description}</p>
            <h2 className='my-4'>Price: {productDetails.price}</h2>
            <NavLink to={`/products/${id}/feedback`}>
                 <button className=' lg btn btn-outline-secondary my-5'>Feedback</button>
            </NavLink>
           </div>
        </div>
      </div>
    </>
  );
};
export default ProductDetails;
