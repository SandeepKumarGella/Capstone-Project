import React from 'react';
import { render, waitFor } from '@testing-library/react';
import axios from 'axios';
import ProductDetails from './ProductDetails';

jest.mock('axios');

describe('ProductDetails component', () => {
  test('renders loading state', async () => {
    axios.get.mockResolvedValue({
      data: {
        url: '',
        title: '',
        description: '',
        price: ''
      }
    });

    const { getByTestId } = render(<ProductDetails />);

    const loader = getByTestId('loader');
    expect(loader).toBeInTheDocument();
  });

  test('renders error state', async () => {
    axios.get.mockRejectedValue(new Error('Unable to fetch data'));

    const { getByText } = render(<ProductDetails />);

    await waitFor(() => {
      const errorMessage = getByText('Unable to fetch data. Try again after sometime!');
      expect(errorMessage).toBeInTheDocument();
    });
  });
});
