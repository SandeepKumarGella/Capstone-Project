import React, { Suspense } from 'react';
import { Routes, Route } from 'react-router-dom';
import PageNotFound from '../components/PageNotFound/PageNotFound';
import ContactUsContent from '../pages/ContactUsPage/ContactUsContent';
import Feedback from '../pages/ProductsPage/Feedback/Feedback';
import ProductDetails from '../pages/ProductsPage/TabProduct/ProductDetails';
import AboutContent from '../pages/AboutPage/AboutContent';
import HomePage from '../pages/HomePage/HomePage';
// for Lazy Loading
const AboutPage = React.lazy(() => import('../pages/AboutPage/AboutPage'));
const ProductsPage = React.lazy(() => import('../pages/ProductsPage/ProductsPage'));
const ContactUsPage = React.lazy(() => import('../pages/ContactUsPage/ContactUsPage'));

const appRoutes = (
  <Suspense fallback={<div className="spinner-border text-warning"></div>}>
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/about-us" element={<AboutPage />}>
        <Route path="content" element={<AboutContent />} />
      </Route>
      <Route path="/contact-us" element={<ContactUsPage />} />
      <Route path="/contact-us/content" element={<ContactUsContent />} />
      <Route path="/products" element={<ProductsPage />}/>
      <Route path="/products/:id" element={<ProductDetails/>} />
      <Route path="/products/:id/feedback" element={<Feedback/>} />
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  </Suspense>
);

export default appRoutes;
