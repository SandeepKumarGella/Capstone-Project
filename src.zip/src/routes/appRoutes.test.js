import React from 'react';
import { render, cleanup } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import appRoutes from './appRoutes';
import renderer from 'react-test-renderer';

afterEach(cleanup);

describe('Test lazy loaded component', () => {
  it('renders the contactUs component correctly', async () => {
    const { findByText } = render(
      <MemoryRouter initialEntries={['/contact-us']}>
        {appRoutes}
      </MemoryRouter>
    );
    const contactUsPage = await findByText('Contact Us');
    expect(contactUsPage).toBeInTheDocument();
  });

  it('renders the productsPage component correctly', async () => {
    const { findByText } = render(
      <MemoryRouter initialEntries={['/products']}>
        {appRoutes}
      </MemoryRouter>
    );
    const productPage = await findByText('Our Collections');
    expect(productPage).toBeInTheDocument();
  });

  it('renders the aboutPage component correctly', async () => {
    const { findByText } = render(
      <MemoryRouter initialEntries={['/about-us']}>
        {appRoutes}
      </MemoryRouter>
    );
    const aboutPage = await findByText('Content');
    expect(aboutPage).toBeInTheDocument();
  });

});

describe('appRoutes component', () => {
  it('should render correctly', () => {
    const snapshotInJson = renderer.create(<appRoutes />).toJSON();
    expect(snapshotInJson).toMatchSnapshot();
  });
});






